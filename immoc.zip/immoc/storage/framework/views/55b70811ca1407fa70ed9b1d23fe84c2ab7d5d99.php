<form class="form-horizontal" method="POST" action="">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="name" class="col-sm-2 control-label">姓名</label>
        <div class="col-sm-5">
            <input type="text" name="Student[name]"
                   value="<?php echo e(old('Student')['name']?old('Student')['name']:$student->name); ?>"
                   class="form-control" id="name" placeholder="请输入学生姓名">
        </div>
        <div class="col-sm-5">
            <p class="form-control-static text-danger"><?php echo e($errors->first('Student.name')); ?></p>
        </div>
    </div>
    <div class="form-group">
        <label for="age" class="col-sm-2 control-label">年龄</label>

        <div class="col-sm-5">
            <input type="text" name="Student[age]"
                   value="<?php echo e(old('Student')['age']?old('Student')['age']:$student->age); ?>"
                   class="form-control" id="age" placeholder="请输入学生年龄">
        </div>
        <div class="col-sm-5">
            <p class="form-control-static text-danger"><?php echo e($errors->first('Student.age')); ?></p>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">性别</label>

        <div class="col-sm-5">
            <?php $__currentLoopData = $student->sex(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="radio-inline">
                    <input type="radio" name="Student[sex]"
                           <?php echo e(isset($student->sex) && $student->sex == $ind ? 'checked':''); ?>

                    value="<?php echo e($ind); ?>"> <?php echo e($val); ?>

                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-sm-5">
            <p class="form-control-static text-danger"><?php echo e($errors->first('Student.sex')); ?></p>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">提交</button>
        </div>
    </div>
</form>
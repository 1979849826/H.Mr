<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('common.validator', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="panel panel-default">
        <div class="panel-heading">修改学生</div>
        <div class="panel-body">
            <?php echo $__env->make('student._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('common.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>